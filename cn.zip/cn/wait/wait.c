#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
	pid_t w,p;int i;
	for(i=0;i<10;i++)
	{
		p=fork();
		if(p==0)
		{
			sleep(5+i);
			printf("child %d is terminated\n",i+1);
			break;
		}
		else
		{
			if(i==2)
			w=p;
		}
	}
	if(p==0)
	return 0;
	waitpid(w,NULL,0);
	printf("parent terminated\n");
}
