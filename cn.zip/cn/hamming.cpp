#include<unistd.h>
#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	 
	char buffer[20];
	int count=0;
	printf("enter data\n");
	scanf("%s",buffer);

	int replace;	
	printf("enter index to be replaced\n");
	scanf("%d",&replace);

	int bits=strlen(buffer);
	while(bits!=0)
	{
		bits=bits/2;
		count++;
	}
	bits=count+strlen(buffer);
	count=0;
	while(bits!=0)
	{
		bits=bits/2;
		count++;
	}
	bits=count;
	
	char data[strlen(buffer)+bits];
	int power=0,fill=0;
	for(int i=0;i<sizeof(data);i++)
	{
		if(i+1==pow(2,power))
		{
			data[i]='0';
			power++;
		}
		else
		{
			data[i]=buffer[fill];
			fill++;
		}
	}
	
	power=0 ;
	while(pow(2,power)<=sizeof(data))
	{
		int rep=pow(2,power)-1,count=0;
		 
		
		for(int j=1;j<=sizeof(data);j++)
		{
			int test=0,power1=0;
			while(pow(2,power1)<=sizeof(data))
			{
				if(j==pow(2,power1))
				{
					test=1;
					break;
				}
				else
				power1++;
			}
			if(test==0)
			{
				int v=j>>power;
				v=v%2;
				if(v==1)
				{
					 
					if(data[j-1]=='1')
					count++;
				}
			}
		}
		 
		if(count%2==0)
		data[rep]='0';
		else
		data[rep]='1';
		power++;
	}
	data[strlen(buffer)+bits]='\0';
	
	printf("data with redundancy bits fiiled : %s\n",data);

	if(data[replace]=='1')
	data[replace]='0';
	else
	data[replace]='1';

	int ans=0;power=0 ;
	while(pow(2,power)<=sizeof(data))
	{
		int count=0,d=pow(2,power);
		printf("%d",d);
		for(int j=1;j<=sizeof(data);j++)
		{		 
				int v=j>>power;
				v=v%2;
				if(v==1)
				{
					 printf("%d ",j);
					if(data[j-1]=='1')
					count++;
			 	}
		}
		printf("%d\n",count);
		if(count%2!=0)
		{
			ans=ans+pow(2,power);	
		}
		power++;

	}	
	 printf("changed bit is %d",ans);	
}
