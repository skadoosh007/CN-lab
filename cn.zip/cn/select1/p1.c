#include<stdio.h>
#include<unistd.h>
#include<string.h>
int main()
{
	sleep(2);
	write(1,"p1_sent_the_message",strlen("p1_sent_the_message"));
}
