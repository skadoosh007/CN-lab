#include<stdio.h>
#include<unistd.h>
#include<string.h>
int main()
{
	char buffer[30];
	
	while(1)
	{	memset(buffer,'\0',sizeof(buffer));		
		int k= read(0,buffer,sizeof(buffer));
		if(k>0)
		{
			printf("%s\n",buffer);
		}
		
	}

	
}
