#include<stdio.h>
#include<unistd.h>
#include<string.h>
int main()
{
	sleep(5);
	write(1,"p2_sent_the_message",strlen("p2_sent_the_message"));
}
