#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/select.h>
int max(int a,int b)
{
	if(a>b)
	return a;
	return b;
}
int main()
{
	struct timeval tvptr;
	int ret=0;
	fd_set rset;
	
	int check=0;

	int fd[3];
	fd[0]=fileno(popen("./p1","r"));
	
	fd[1]=fileno(popen("./p2","r"));
	
	fd[2]=fileno(popen("./p3","r"));
	

	int f=fileno(popen("./p4","w"));
	
	while(1)
	{
		tvptr.tv_sec=3;
		tvptr.tv_usec=10;
		FD_ZERO(&rset);
		FD_SET(fd[2],&rset);FD_SET(fd[1],&rset);FD_SET(fd[0],&rset);
		
		int m=max(fd[0],fd[1]);
		m=max(m,fd[2]);
		int prev=ret;
		ret=select(m+1,&rset,NULL,NULL,&tvptr);
		//printf("%d\n",ret);

               if(ret>0)
		{
			//check=0;
			for(int i=0;i<3;i++)
			{
				char buffer[20];
				if(FD_ISSET(fd[i],&rset))
				{
					read(fd[i],buffer,sizeof(buffer));
					//fflush(fd[i]);
					printf("%s\n",buffer);
					//write(f,buffer,strlen(buffer));
				}
			}
		}
	}
}
