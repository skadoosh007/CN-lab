#include<signal.h>
#include<unistd.h>
//#include<sys/siginfo.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
int main()
{
	
	printf("enter pid \n");
	pid_t p;
	scanf("%d",&p);
	kill(p,SIGUSR1);
	//signal(SIGUSR1,fn);
	while(1){}
	
}
