#include<stdio.h>
#include<unistd.h>
#include<sys/select.h>

int main()
{
	char buffer[20];
	scanf("%s",&buffer);
	printf("printing : %s",buffer);
}
