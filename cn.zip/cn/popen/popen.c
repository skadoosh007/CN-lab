#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<fcntl.h>
int main()
{
	int fd=fileno(popen("./test","w"));
	char buffer[100];
	scanf("%s",buffer);
	write(fd,buffer,strlen(buffer)+1);

}
