#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/types.h>
#include<sys/select.h>
#include<arpa/inet.h>
#include<signal.h>
#include<fcntl.h>
#include<sys/stat.h>

int main()
{ 
	printf("admin\n");
	char* myfifo="random";
	int p=mkfifo(myfifo,0666);
	printf("%d\n",p);
	

	while(1)
	{
		printf("enter number\n");
		char k[1];
		scanf("%s",k);
		int fd=open(myfifo,O_WRONLY);
		
		write(fd,k,1);
		close(fd);
	}
}
