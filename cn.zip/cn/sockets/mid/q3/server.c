#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
#include<signal.h>
#include<sys/select.h>
#include<pthread.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<math.h>
#include<stdlib.h>

int s1_lim=1;	
int s4_lim=1;
int s1_c=0;
int s4_c=0;
int s2_c=0;
int s2_lim=4;
int nsfd1;

void fn1(int sig)
{
	s1_c--;
	printf("s1 count reduced\n");
}
void fn2(int sig)
{
	s4_c--;
	printf("s4 count reduced\n");
}

void *myThreadFun(void *vargp) 
{
	char buffer[100];
	int k=read(nsfd1,buffer,sizeof(buffer));
	k--;
	memset(&buffer,0,sizeof(buffer));
	sprintf(buffer,"length of string is %d",k);
	write(nsfd1,buffer,strlen(buffer));	
	s2_c--;
	pthread_exit(0);				 
}
int main()
{
	int sfd[10],m=-1;
	int c=0;
 	int op[10];
	int port[10];
	sfd[c]=socket(AF_INET,SOCK_STREAM,0);
	if(sfd[c]>m)
	m=sfd[c];
	if(sfd[c]==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(8000+c);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	
	if(bind(sfd[c],(struct sockaddr*)&address,sizeof(address))<0)
	{
		printf("bind error\n");
		return 0;
	}
	
	listen(sfd[c],5);
	c++;

	sfd[c]=socket(AF_INET,SOCK_STREAM,0);
	if(sfd[c]>m)
	m=sfd[c];	
	if(sfd[c]==0)
	{
		printf("socket error\n");
		return 0;
	}

	address.sin_family=AF_INET;
	address.sin_port=htons(8000+c);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	
	if(bind(sfd[c],(struct sockaddr*)&address,sizeof(address))<0)
	{
		printf("bind error\n");
		return 0;
	}
	listen(sfd[c],5);
	c++;

	sfd[c]=socket(AF_INET,SOCK_DGRAM,0);
	if(sfd[c]>m)
	m=sfd[c];
	if(sfd[c]==0)
	{
		printf("socket error\n");
		return 0;
	}

	address.sin_family=AF_INET;
	address.sin_port=htons(8000+c);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	
	if(bind(sfd[c],(struct sockaddr*)&address,sizeof(address))<0)
	{
		printf("bind error\n");
		return 0;
	}
	c++;

	sfd[c]=socket(AF_INET,SOCK_STREAM,0);
	if(sfd[c]>m)
	m=sfd[c];
	if(sfd[c]==0)
	{
		printf("socket error\n");
		return 0;
	}

	address.sin_family=AF_INET;
	address.sin_port=htons(8000+c);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	
	if(bind(sfd[c],(struct sockaddr*)&address,sizeof(address))<0)
	{
		printf("bind error\n");
		return 0;
	}
	
	listen(sfd[c],5);
	c++;
	
	char* myfifo="random";
	mkfifo(myfifo,0666);
	
	c++;
	printf("fifo created\n");
	
	int k=1,p=1,h=1;

	signal(SIGUSR1,fn1);
	signal(SIGUSR2,fn2);
	
	for(int i=0;i<c;i++)
	op[i]=1;
	//select 
	while(1)
	{
		struct timeval tvptr;
		fd_set rset;
		tvptr.tv_sec=1;
		tvptr.tv_usec=0;
		FD_ZERO(&rset);
		sfd[4]=open(myfifo,O_RDONLY);
		if(m<sfd[4])
		m=sfd[4];		
		for(int i=0;i<c;i++)
		FD_SET(sfd[i],&rset);
		
		int ret=select(m+1,&rset,NULL,NULL,&tvptr);
		if(ret>0)
		{
			for(int i=0;i<c;i++)
			{
				if(FD_ISSET(sfd[i],&rset))
				{
					if(i==1&&op[i]==1)
					{
						if(s2_c<s2_lim)
						{
							 nsfd1=accept(sfd[i],NULL,NULL);
							printf("new thread created for s2\n");
							 s2_c++;
							pthread_t p;
							pthread_create(&p,NULL,myThreadFun,NULL);
						}
					        else
						{
							if(h==1)
							{printf("too many req for s2\n");
							h=0;}
						}
					}
					if(i==2&&op[i]==1)
					 { 
						//udp 
						char buffer[100];
						struct sockaddr_in cliaddr;
						int len,n;
						n = recvfrom(sfd[2], (char *)buffer, sizeof(buffer),MSG_DONTWAIT,( struct sockaddr *) &cliaddr,&len);
						buffer[n] = '\0';
        					printf("msg from udp client : %s\n",buffer);
					 }
					if(i==0&&op[i]==1)
					{			 
						if(s1_c<s1_lim)
						{
							p=1;
							s1_c++;
							printf("new s1 service alloted\n");
							int nsfd=accept(sfd[i],NULL,NULL);
							pid_t pid=fork();

							if(pid==0)
							{
								dup2(0,2);
								dup2(1,3); 
								dup2(nsfd,0);
								dup2(nsfd,1);
								
								char * a[]={"oka",NULL};
								execvp("./s1",a);
							}
						}
						else
						{
							if(p==1)
							{printf("too many req for s1\n");
							p=0;}
						}
					}
					if(i==3&&op[i]==1)
					{	 
						if(s4_c<s4_lim)
						{
							k=1;
							s4_c++;
							printf("new s4 service alloted\n");
							int nsfd=accept(sfd[i],NULL,NULL);
							pid_t pid=fork();
	
							if(pid==0)
							{
								dup2(nsfd,0);
								dup2(nsfd,1);
								
								char * a[]={"oka",NULL};
								execvp("./s4",a);
							}
						}
						else
						{
							if(k==1)
							{printf("too many req for s4\n");
							k=0;}
						}
						
					}
					if(i==4)
					{
						
						char buf[1];
						int num=read(sfd[i],buf,1);
						if(num==0)printf("read nothing\n");
						if(num>0)
						{
							printf("admin sent msg\n");
						int number=atoi(buf);
						number--;
	
						if(op[number]==1)
						{
							printf("service %d is no longer available\n",number+1);
							//close(sfd[number]);
							op[number]=0;
						}
						else if(op[number]==0)
						{
							printf("service %d is now available\n",number+1);
							/*sfd[number]=socket(AF_INET,SOCK_STREAM,0);
							if(sfd[number]>m)
							m=sfd[number];
							if(sfd[number]==0)
							{
							printf("socket error\n");
							return 0;
							}
							address.sin_family=AF_INET;
							address.sin_port=htons(8000+number);
							address.sin_addr.s_addr=inet_addr("127.0.0.1");
							//bind the socket to address
							if(bind(sfd[number],(struct sockaddr*)&address,sizeof(address))<0)	

							{
							printf("bind error\n");
							return 0;
							}*/
							op[number]=1;
							
						}
						
						}
					}	
				}
			}
		}
		close(sfd[4]);
	}
}
