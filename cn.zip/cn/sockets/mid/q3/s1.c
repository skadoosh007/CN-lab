#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/types.h>
#include<sys/select.h>
#include<arpa/inet.h>
#include<signal.h>

int main()
{
	 char buffer[100];
	 char hello[20];
     
	 //read from client
	 int k=read(0,hello,sizeof(hello));

	 //print to console
	 write(3,hello,k);

	 //read from console
	 write(3,"enter msg\n",10);
	 k=read(2,buffer,sizeof(buffer));
	 //send to client	
	 write(1,buffer,k);
	 
	 kill(getppid(),SIGUSR1);
}
