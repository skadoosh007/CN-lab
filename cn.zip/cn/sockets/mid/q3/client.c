#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
int main()
{
	printf("enter service..1 2 3 4\n");
	int s;
	scanf("%d",&s);
	
	s=s-1+8000;
	//opening socket
	int sfd;
	if(s!=8002)
	sfd=socket(AF_INET,SOCK_STREAM,0);
	else
	sfd=socket(AF_INET,SOCK_DGRAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(s);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//connect the socket to address
	int p=sizeof(address);
	if(s!=8002)
	{
		int ret=connect(sfd,(struct sockaddr*)&address,(socklen_t)p);
		
		if(ret<0)
		{
			printf(" connection error\n");
			return 0;
		}
	}
	
	char buffer[100]={0};
	printf("connected\n");

	if(s!=8002)
	{
			
	printf("enter message\n");
	memset(&buffer,'\0',100);
	read(0,buffer,100);
	send(sfd,buffer,strlen(buffer),0);

	char buffer1[30];
	int k=recv(sfd,buffer1,30,0);
	buffer1[k]='\0';
	write(1,buffer1,k);
	}	

	else if(s==8002)
	{ 
	
		int n, len; 
		printf("enter message\n");
		char hello[30];
		scanf("%s",hello);	
		sendto(sfd, (const char *)hello, strlen(hello), 
		MSG_CONFIRM, (const struct sockaddr *) &address, 
			sizeof(address)); 
	}
}
	 
