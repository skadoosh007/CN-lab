#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<arpa/inet.h>
#include<signal.h>
int main()
{ 
	char buffer[100];
	int k=read(0,buffer,sizeof(buffer));
	k--;
	int d=strlen(buffer);
	memset(&buffer,0,sizeof(buffer));
	sprintf(buffer,"length of string is %d",k);
	write(1,buffer,strlen(buffer));
	kill(getppid(),SIGUSR2);
}
