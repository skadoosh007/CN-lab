#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
#include<signal.h>
#include<sys/select.h>
#include<sys/types.h>
#include<pthread.h>
#include<stdlib.h>

int main()
{
	int sfd[10];
	pid_t pid[10];
	sfd[0]=0;
	
	int m=0;
	if ( (sfd[1] = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
		perror("socket creation failed"); 
		return 0; 
	}  
	if(sfd[1]>m)
	m=sfd[1];
	
	// Filling server information
	struct sockaddr_in servaddr; 
	servaddr.sin_family = AF_INET; // IPv4 struct sockaddr_in address;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(9000); 
	
	// Bind the socket with the server address 
	if ( bind(sfd[1], (const struct sockaddr *)&servaddr, 
			sizeof(servaddr)) < 0 ) 
	{ 
		perror("bind failed"); 
		return 0;
	} 
	
	int c=2,x=1;
	while(1)
	{
		fd_set rset;
		FD_ZERO(&rset);
		for(int i=0;i<c;i++)
		FD_SET(sfd[i],&rset);
		
		struct timeval tvptr;
		tvptr.tv_sec=1;
		tvptr.tv_usec=0;
		
		int ret=select(m+1,&rset,NULL,NULL,&tvptr);
		if(ret>0)
		{
			for(int i=0;i<c;i++)
			{
				if(FD_ISSET(sfd[i],&rset))
				{
					if(i==0)
					{
						printf("set\n");
						char buffer[20];
						int r=read(0,buffer,sizeof(buffer));
						buffer[r-1]='\0';
						char port[4];
						for(int j=0,k=0;k<4;j++,k++)
						port[k]=buffer[j];

						
						 			
												
						sfd[c]=socket(AF_INET,SOCK_STREAM,0);

						if(sfd[c]>m)
						m=sfd[c];
						
						servaddr.sin_port = htons(atoi(port));
							int optval=1;
						//setsockopt(sfd[c],SOL_SOCKET,  SO_REUSEPORT, &optval, sizeof(optval));
						if ( bind(sfd[c], (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0 ) 
						{ 
							printf("bind error");
							return 0; 
						}
						listen(sfd[c],2);

						pid[c]=fork();
						if(pid[c]==0)
						{
							char file[10]="./s1";
							for(int j=4,k=0;j<strlen(buffer);j++,k++)
							file[k]=buffer[j];
							
							printf("new socket added %d %s\n",atoi(port),file);
							char* a[]={port,NULL};
							execvp(file,a);
						}
						c++;
					}
					else if(i==1)
					{
						
					}
					else
					{
						
						printf("new req for service %d\n",i-1);
						kill(pid[i],SIGUSR1);
						sleep(5);	
					}
				}
			}
		}
	}
	
}
