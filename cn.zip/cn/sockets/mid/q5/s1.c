#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
#include<signal.h>
#include<sys/select.h>
#include<pthread.h>
#include<stdlib.h>
int notif=0;
int nsfd,sfd;
void *myThreadFun(void *vargp) 
{
	char buffer[100];
	int k=read(nsfd,buffer,sizeof(buffer));
	k--;
	memset(&buffer,0,sizeof(buffer));
	sprintf(buffer,"length of string is %d",k);
	write(nsfd,buffer,strlen(buffer));	
	pthread_exit(0);				 
}
void fn()
{
	printf("signal\n");
	notif=1;
	listen(sfd,2);
	printf("new thread created for s1\n");
	nsfd=accept(sfd,NULL,NULL);
	pthread_t p;
	pthread_create(&p,NULL,myThreadFun,NULL);
	printf("notified\n");
}
int main(int argc,char* argv[])
{ 
	signal(SIGUSR1,fn);
	
	int port=atoi(argv[0]);
	struct sockaddr_in servaddr;
	servaddr.sin_family = AF_INET; // IPv4 struct sockaddr_in address;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");; 
	servaddr.sin_port = htons(port); 

	sfd=socket(AF_INET,SOCK_STREAM,0);
	int optval=1;
	int k=setsockopt(sfd,SOL_SOCKET,  SO_REUSEPORT, &optval, sizeof(optval));
	printf("%d\n",k);if (bind(sfd,(const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0 ) 
	{ 
		printf("bind error");
		return 0; 
	}
	while(1);
	
}
