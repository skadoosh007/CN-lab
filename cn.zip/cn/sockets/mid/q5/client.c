#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
int main()
{
	printf("enter service..1 2 3 4\n");
	int s;
	scanf("%d",&s);
	
	s=s+9000;
	//opening socket
	int sfd; 
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(s);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//connect the socket to address
	int p=sizeof(address);
	int ret=connect(sfd,(struct sockaddr*)&address,(socklen_t)p);	
	if(ret<0)
	{
		printf(" connection error\n");
		return 0;
	}
	 	
	char buffer[100]={0};
	printf("connected\n");

 		
	printf("enter message\n");
	memset(&buffer,'\0',100);
	read(0,buffer,100);
	send(sfd,buffer,strlen(buffer),0);

	char buffer1[30];
	int k=recv(sfd,buffer1,30,0);
	buffer1[k]='\0';
	write(1,buffer1,k);
		

	 
}
	 
