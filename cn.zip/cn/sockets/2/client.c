#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

int main()
{
	int sfd;

	//opening socket
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	connect(sfd,(struct sockaddr*)&address,sizeof(address));

	while(1)
	{
		char buffer[100];
		memset(buffer,'\0',100);
		printf("enter message\n");
		read(0,buffer,sizeof(buffer));
		send(sfd,buffer,strlen(buffer),0);
		memset(buffer,'\0',100);
		recv(sfd,buffer,sizeof(buffer),0);
		printf("message from server: %s\n",buffer);
 	}
	//close
	close(sfd);

}
