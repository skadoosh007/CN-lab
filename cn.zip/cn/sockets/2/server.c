#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

int main()
{
	int sfd;

	//opening socket
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	bind(sfd,(struct sockaddr*)&address,sizeof(address));
	
	listen(sfd,5);

	int nsfd;
	int c=0;
	while(1)
	{
		nsfd=accept(sfd,NULL,NULL);
		printf("new connection established\n");
		
		pid_t pid=fork();
		
		if(pid>0)
		continue;

		if(pid==0)
		{
			while(1)
			{
				char buffer[100];
				recv(nsfd,buffer,sizeof(buffer),0);
				send(nsfd,buffer,strlen(buffer),0);
			}
		}
		
	}	
	//close
	close(sfd);

}

