#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<arpa/inet.h>

int max(int a,int b)
{
	if(a>b)
	return a;
	return b;
}

int main()
{
	int sfd;

	//opening socket
	int sfd1=socket(AF_INET,SOCK_STREAM,0);
	if(sfd1==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address1;
	address1.sin_family=AF_INET;
	address1.sin_port=htons(8001);
	address1.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	int p=sizeof(address1);
	if(bind(sfd1,(struct sockaddr*)&address1,(socklen_t)p)<0){printf("\nbind error\n");}
	
	listen(sfd1,5);

	//opening socket
	int sfd2=socket(AF_INET,SOCK_STREAM,0);
	if(sfd2==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address2;
	address2.sin_family=AF_INET;
	address2.sin_port=htons(8002);
	address2.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	p=sizeof(address2);
	if(bind(sfd2,(struct sockaddr*)&address2,(socklen_t)p)<0){printf("\nbind error\n");}
	
	listen(sfd2,5);
 
	struct timeval tvptr;
	fd_set rset;
	
	while(1)
	{
		tvptr.tv_sec=1;
		tvptr.tv_usec=0;
		FD_ZERO(&rset);
		FD_SET(sfd1,&rset);FD_SET(sfd2,&rset);
		
		int m=max(sfd1,sfd2);
		int ret=select(m+1,&rset,NULL,NULL,&tvptr);
		//printf("\n%d\n",ret);
		if(ret<0)
		{printf("error");}
		if(ret>0)
		{	
			printf("\nselect\n");
			if(FD_ISSET(sfd1,&rset))
			{
				int nsfd=accept(sfd1,NULL,NULL);
				pid_t pid=fork();
			
				if(pid==0)
				{
					printf("new req for service 1\n");
					dup2(nsfd,2);
					char * a[]={"oka",NULL};
					execvp("./s1",a);
				}
				
			}
			if(FD_ISSET(sfd2,&rset))
			{
				int nsfd=accept(sfd2,NULL,NULL);
				pid_t pid=fork();
			
				if(pid==0)
				{
					printf("new req for service 2\n");
					dup2(nsfd,2);
					char * a[]={"oka",NULL};
					execvp("./s2",a);
				}		
			}
		}		 		
	}
	//close
	close(sfd);
}

