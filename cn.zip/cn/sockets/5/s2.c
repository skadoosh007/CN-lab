#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>

int main()
{
	write(2,"hello..am_server2",strlen("hello..am_server2"));
	while(1)
	{
		char buffer[100];
		memset(buffer,'\0',100);
		read(2,buffer,sizeof(buffer));
		printf("%s\n",buffer);
	}
}
