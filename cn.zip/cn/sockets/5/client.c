#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
int main()
{
	printf("enter service..1 or 2\n");
	int s;
	scanf("%d",&s);
	
	s=s+8000;
	//opening socket
	int sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(s);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//connect the socket to address
	int p=sizeof(address);
	int ret=connect(sfd,(struct sockaddr*)&address,(socklen_t)p);
	printf("%d\n",ret);	
	if(ret<0)
	printf("error\n");
	char buffer[100];
	printf("connected\n");
	recv(sfd,buffer,sizeof(buffer),0);
	printf("%s\n",buffer);

	while(1)
	{
		printf("enter message\n");
		memset(buffer,'\0',100);
		scanf("%s",buffer);
		send(sfd,buffer,strlen(buffer),0);
	}
}
	 
