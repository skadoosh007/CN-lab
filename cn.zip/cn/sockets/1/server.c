#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
int main()
{
	int sfd;

	//opening socket
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("192.168.137.93");

	//bind the socket to address
	bind(sfd,(struct sockaddr*)&address,sizeof(address));
	
	listen(sfd,1);

	int nsfd,ad=sizeof(address);
	 
	nsfd=accept(sfd,NULL,NULL);
	 
	//write to nsfd
	char buffer[100];
	memset(buffer,'\0',100);
	printf("enter message\n");
	int k=read(0,buffer,sizeof(buffer));
	send(nsfd,buffer,strlen(buffer)-1,0);
	 
	close(sfd);

}
