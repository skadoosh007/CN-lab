#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>

int main()
{
	int sfd;

	//opening socket
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("192.168.177.1");

	//connect to addr 
	int stat=connect(sfd,(struct sockaddr*)&address,sizeof(address));
	if(stat<0)
	printf("connection failed\n");

	//read from sfd
	char buffer[100];
	recv(sfd,buffer,sizeof(buffer),0);
	
	//display
	printf("message from server: %s\n",buffer);
	
	//send msg	
	printf("enter message\n");
	read(0,buffer,sizeof(buffer));
	send(sfd,buffer,strlen(buffer),0);

	//close socket
	close(sfd);

}
