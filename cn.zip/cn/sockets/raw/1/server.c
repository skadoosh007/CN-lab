#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>

int main()
{
	
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	bind(sfd,(struct sockaddr*)&address,sizeof(address));
	
	listen(sfd,1);

	int nsfd,ad=sizeof(address);
	 
	nsfd=accept(sfd,NULL,NULL);
	 
	char buf[100];
	recv(nsfd,buf,100,0);

	char ip[20],file[20];
	int i,k=0;
	for(i=0;i<strlen(buf);i++)
	{
		if(buf[i]!='/')
		{ip[k]=buf[i];k++;}
		else
		break;
	}
	ip[k]='\0';
	printf("IP : %s\n",ip);
	k=0,i++;
	while(i<strlen(buf))
	{
		file[k]=buf[i];
		i++;k++;	
	}
	printf("file : %s\n",file);

	int rsfd=socket(AF_INET,SOCK_RAW,6);
	perror("socket");
	
	int optval=1;
	setsockopt(rsfd, IPPROTO_IP, SO_BROADCAST, &optval, sizeof(int));
	
	struct sockaddr_in client;
	client.sin_family=AF_INET;	
	client.sin_addr.s_addr=inet_addr(ip);

	unsigned int client_len=sizeof(client);
	connect(rsfd,(struct sockaddr*)&client,sizeof(client));
	
	int fd=open(file,'r');
	dup2(rsfd,1);
	dup2(fd,0);
	
  	char* a[]={"./s2",NULL};
	execvp(a[0],a);
 
 }
