#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
int main()
{
		char buffer[100];
		int k=read(0,buffer,100);
		if(k>0)
		write(1,buffer,strlen(buffer));
}
