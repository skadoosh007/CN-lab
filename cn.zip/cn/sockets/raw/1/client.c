#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
void print_ipheader(struct iphdr* ip)
{
	printf("------------------------\n");
	printf("Printing IP header....\n");
	printf("IP version: %d\n",(unsigned int)ip->version);
	printf("IP header length: %d\n",(unsigned int)ip->ihl);
	
	printf("Type of service: %d\n",(unsigned int)ip->tos);
	printf("Total ip packet length: %d\n",ntohs(ip->tot_len));
	printf("Packet id: %d\n",ntohs(ip->id));
	printf("Time to leave: %d\n",(unsigned int)ip->ttl);
	printf("Protocol: %d\n",(unsigned int)ip->protocol);
	//cout<<"Check:"<<ip->check<<endl;
	printf("Source ip: %s\n",inet_ntoa(*(struct in_addr*)&ip->saddr));
	//printf("%pI4\n",&ip->saddr );
	printf("Destination ip: %s\n",inet_ntoa(*(struct in_addr*)&ip->daddr));
	printf("------------------------\n");
}

int main()
{
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	connect(sfd,(struct sockaddr*)&address,sizeof(address));
	
	char buffer1[30],buffer2[10];
	printf("enter ip and file");
	scanf("%s",buffer1);
	scanf("%s",buffer2);

	int rsfd=socket(AF_INET,SOCK_RAW,6);
	struct sockaddr_in client;
	client.sin_family=AF_INET;	
	client.sin_addr.s_addr=inet_addr(buffer1);

	bind(rsfd,(struct sockaddr*)&client,sizeof(client));

	sprintf(buffer1,"%s/%s",buffer1,buffer2);
	send(sfd,buffer1,strlen(buffer1),0);
	
	char buf[30];
	struct sockaddr_in client1;
	socklen_t clilen=sizeof(client1);
	
	int len;
	recvfrom(rsfd,buf,120,0,(struct sockaddr*)&client1,&len);
	perror("recv");
	
	struct iphdr *ip;
	ip=(struct iphdr*)buf;
	print_ipheader(ip);
	printf("%s",buf+(ip->ihl)*4);
}
