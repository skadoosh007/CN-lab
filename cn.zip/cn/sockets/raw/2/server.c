#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>

int main()
{
	
	int sfd;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	int port;
	printf("enter port number\n");
	scanf("%d",&port);
	address.sin_port=htons(port);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	bind(sfd,(struct sockaddr*)&address,sizeof(address));
	
	listen(sfd,1);

	int rsfd=socket(AF_INET,SOCK_RAW,6);
	perror("socket");
	struct sockaddr_in server;
	server.sin_family=AF_INET;
	server.sin_addr.s_addr=inet_addr("127.0.0.1");
	bind(rsfd,(struct sockaddr*)&server,sizeof(server));
	
	int optval=1;
	setsockopt(rsfd, IPPROTO_IP, SO_BROADCAST, &optval, sizeof(int));
	
	struct sockaddr_in client;
	while(1)
	{
		struct timeval tvptr;
		tvptr.tv_sec=1;
		tvptr.tv_usec=0;
		fd_set rset;
		FD_ZERO(&rset);
		FD_SET(sfd,&rset);FD_SET(rsfd,&rset);
		int m;
		if(rsfd>sfd)
		m=rsfd;
		else
		m=sfd;

		int ret=select(m+1,&rset,NULL,NULL,NULL);
		if(ret>0)
		{
			if(FD_ISSET(sfd,&rset))
			{
				pid_t pid;
				pid=fork();
				if(pid==0)
				{
					int nsfd=accept(sfd,NULL,NULL);
					close(sfd);
					close(rsfd);
					while(1)
					{
						char buffer[40];
						memset(buffer,'\0',40);
						recv(nsfd,buffer,40,0);

						
						sprintf(buffer,"the length of string is %d",(int)strlen(buffer));
						send(nsfd,buffer,strlen(buffer),0);
					}
					
				}
			}
			if(FD_ISSET(rsfd,&rset))
			{
				char buf[120]={0};//sprintf("set ");
				struct sockaddr_in client1;
				int len;
				recvfrom(rsfd,buf,120,0,(struct sockaddr*)&client1,&len);
				
				struct iphdr *ip;
				ip=(struct iphdr*)buf;
				if(*(buf+(ip->ihl)*4)!='-')
				{
					memset(buf,'\0',120);
					sprintf(buf,"-%d",port);
					sendto(rsfd,buf,strlen(buf)+1,0,(struct sockaddr*)&client1,len);
				}
			}
		}
	}
	
	
 
 }
