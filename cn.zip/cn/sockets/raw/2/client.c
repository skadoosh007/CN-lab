#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
void print_ipheader(struct iphdr* ip)
{
	printf("------------------------\n");
	printf("Printing IP header....\n");
	printf("IP version: %d\n",(unsigned int)ip->version);
	printf("IP header length: %d\n",(unsigned int)ip->ihl);
	
	printf("Type of service: %d\n",(unsigned int)ip->tos);
	printf("Total ip packet length: %d\n",ntohs(ip->tot_len));
	printf("Packet id: %d\n",ntohs(ip->id));
	printf("Time to leave: %d\n",(unsigned int)ip->ttl);
	printf("Protocol: %d\n",(unsigned int)ip->protocol);
	//cout<<"Check:"<<ip->check<<endl;
	printf("Source ip: %s\n",inet_ntoa(*(struct in_addr*)&ip->saddr));
	//printf("%pI4\n",&ip->saddr );
	printf("Destination ip: %s\n",inet_ntoa(*(struct in_addr*)&ip->daddr));
	printf("------------------------\n");
}

int main()
{
	int rsfd=socket(AF_INET,SOCK_RAW,6);
	char Ip[20];
	memset(Ip,'\0',20);
	printf("enter Ip\n");
	scanf("%s",Ip);
	struct sockaddr_in client;
	client.sin_family=AF_INET;	
	client.sin_addr.s_addr=inet_addr(Ip);

	bind(rsfd,(struct sockaddr*)&client,sizeof(client));

	
	char buf[30]={0};
	struct sockaddr_in server;
	server.sin_family=AF_INET;
	//client.sin_addr.s_addr=inet_addr("127.0.0.1");
	server.sin_addr.s_addr=inet_addr("127.0.0.1");
	sprintf(buf,"Enquiry");
	sendto(rsfd,buf,120,0,(struct sockaddr*)&server,sizeof(server));
	//read(0,buf,10);
	int sfd[3];
	int c=0,m=rsfd,fd=0;
	
	while(1)
	{
		struct timeval tvptr;
		tvptr.tv_sec=1;
		tvptr.tv_usec=0;
		fd_set rset;
		FD_ZERO(&rset);

		FD_SET(rsfd,&rset);
		FD_SET(fd,&rset);

		int ret=select(m+1,&rset,NULL,NULL,&tvptr);
		if(ret>0)
		{
			if(FD_ISSET(rsfd,&rset))
			{
				char buf[120]={0};
				recvfrom(rsfd,buf,120,0,NULL,NULL);
				struct iphdr *ip;
				ip=(struct iphdr*)buf;
				printf("port : %s\n",(buf+1+(ip->ihl)*4));//read(0,buf,100);

				sfd[c]=socket(AF_INET,SOCK_STREAM,0);
				if(sfd[c]==-1)
				{
					printf("socket error\n");
					return 0;
				}

				struct sockaddr_in address;
				address.sin_family=AF_INET;
				address.sin_port=htons(atoi(buf+1+(ip->ihl)*4));
				address.sin_addr.s_addr=inet_addr("127.0.0.1");

				connect(sfd[c],(struct sockaddr*)&address,sizeof(address));
				printf("connected to above port %d\n",c+1);
				c++;				
			}
			if(FD_ISSET(fd,&rset))
			{
				char buf[20];
				memset(buf,'\0',20);
				scanf("%s",buf);
				for(int i=0;i<c;i++)
				{
					send(sfd[i],buf,strlen(buf),0);
					char buffer[40];
					recv(sfd[i],buffer,40,0);
					printf("service %d :%s\n",i+1,buffer);	
				}
			}
		}
		
	}
	 
}
