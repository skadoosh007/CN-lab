#include<time.h>
#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<sys/select.h>
#include<pthread.h>
#include<signal.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/shm.h>
#include<unistd.h>
#include<sys/un.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
#include<errno.h>
#include<netinet/if_ether.h>
#include<net/ethernet.h>
#include<netinet/ether.h>
#include<netinet/udp.h>
int main()
{
	int sfd;
	if((sfd = socket(AF_INET,SOCK_STREAM,0))==-1)
	perror("socket ");
	else printf("socket created successfully\n");

	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(9001);
	serv_addr.sin_addr.s_addr = INADDR_ANY;

	char buff[30];
	printf("enter data\n");
	scanf("%s",buff);

	if(connect(sfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr))==-1)
	perror("connect : ");
	else printf("connect successful\n");

	
	send(sfd,buff,strlen(buff),0);
	printf("sent data %s\n",buff);
	char buff1[30];
	recv(sfd,buff1,30,0);
	printf("received data %s\n",buff1);
	int flag=0;
	if(strcmp(buff,buff1)==0)
	flag=1;
	
	memset(buff,'\0',30);
	if(flag==1)
	sprintf(buff,"strings matched");
	else
	sprintf(buff,"strings not matched");

	send(sfd,buff,strlen(buff),0);
	printf("sent data %s\n",buff);
	sleep(10);

	memset(buff,'\0',30);
	recv(sfd,buff,30,0);
	printf("%s\n",buff);

	
}

