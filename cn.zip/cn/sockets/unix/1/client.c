#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<sys/un.h>
#include<string.h>

int main()
{
	int usfd;

	usfd=socket(AF_UNIX,SOCK_STREAM,0);
	if(usfd<0)
	printf("socket error\n");
	
	struct sockaddr_un serv;
	serv.sun_family=AF_UNIX;
	strcpy(serv.sun_path,"mysocket");

	int b=connect(usfd,(struct sockaddr*)&serv,sizeof(serv));
	if(b<0)
	printf("connect error\n");

	char buf[10];
	printf("enter text\n");
	read(0,buf,10);
	send(usfd,buf,strlen(buf),0);

}
