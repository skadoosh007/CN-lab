#include<sys/un.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
#include<signal.h>
#include<sys/select.h>
#include<pthread.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<math.h>
#include<stdlib.h>

int usfd,sfd,nsfd[5];
int port;
int up=1;
int c=0,m;
pid_t bkp;

int recv_fd(int socket)
{
  int sent_fd, available_ancillary_element_buffer_space;
  struct msghdr socket_message;
  struct iovec io_vector[1];
  struct cmsghdr *control_message = NULL;
  char message_buffer[1];
  char ancillary_element_buffer[CMSG_SPACE(sizeof(int))];

  /* start clean */
  memset(&socket_message, 0, sizeof(struct msghdr));
  memset(ancillary_element_buffer, 0, CMSG_SPACE(sizeof(int)));

  /* setup a place to fill in message contents */
  io_vector[0].iov_base = message_buffer;
  io_vector[0].iov_len = 1;
  socket_message.msg_iov = io_vector;
  socket_message.msg_iovlen = 1;

  /* provide space for the ancillary data */
  socket_message.msg_control = ancillary_element_buffer;
  socket_message.msg_controllen = CMSG_SPACE(sizeof(int));

  if(recvmsg(socket, &socket_message, MSG_CMSG_CLOEXEC) < 0)
   return -1;

  if(message_buffer[0] != 'F')
  {
   /* this did not originate from the above function */
   return -1;
  }

  if((socket_message.msg_flags & MSG_CTRUNC) == MSG_CTRUNC)
  {
   /* we did not provide enough space for the ancillary element array */
   return -1;
  }

  /* iterate ancillary elements */
   for(control_message = CMSG_FIRSTHDR(&socket_message);
       control_message != NULL;
       control_message = CMSG_NXTHDR(&socket_message, control_message))
  {
   if( (control_message->cmsg_level == SOL_SOCKET) &&
       (control_message->cmsg_type == SCM_RIGHTS) )
   {
    sent_fd = *((int *) CMSG_DATA(control_message));
    return sent_fd;
   }
  }

  return -1;
}

int send_fd(int socket, int fd_to_send)
{
  struct msghdr socket_message;
  struct iovec io_vector[1];
  struct cmsghdr *control_message = NULL;
  char message_buffer[1];
  /* storage space needed for an ancillary element with a paylod of length is CMSG_SPACE(sizeof(length)) */
  char ancillary_element_buffer[CMSG_SPACE(sizeof(int))];
  int available_ancillary_element_buffer_space;

  /* at least one vector of one byte must be sent */
  message_buffer[0] = 'F';
  io_vector[0].iov_base = message_buffer;
  io_vector[0].iov_len = 1;

  /* initialize socket message */
  memset(&socket_message, 0, sizeof(struct msghdr));
  socket_message.msg_iov = io_vector;
  socket_message.msg_iovlen = 1;

  /* provide space for the ancillary data */
  available_ancillary_element_buffer_space = CMSG_SPACE(sizeof(int));
  memset(ancillary_element_buffer, 0, available_ancillary_element_buffer_space);
  socket_message.msg_control = ancillary_element_buffer;
  socket_message.msg_controllen = available_ancillary_element_buffer_space;

  /* initialize a single ancillary data element for fd passing */
  control_message = CMSG_FIRSTHDR(&socket_message);
  control_message->cmsg_level = SOL_SOCKET;
  control_message->cmsg_type = SCM_RIGHTS;
  control_message->cmsg_len = CMSG_LEN(sizeof(int));
  *((int *) CMSG_DATA(control_message)) = fd_to_send;

  return sendmsg(socket, &socket_message, 0);
}

void fn()
{
	if(up==1)
	{
		up=0;
		printf("\nthis server is down\n");
	
		usfd=socket(AF_UNIX,SOCK_STREAM,0);
		if(usfd<0)
		printf("socket error\n");
		
		struct sockaddr_un serv;
		serv.sun_family=AF_UNIX;
		strcpy(serv.sun_path,"mysocket");
		int b=connect(usfd,(struct sockaddr*)&serv,sizeof(serv));
		if(b<0)
		printf("connect error\n");
	
		char buf[1];
		buf[0]=port-9000+48;
		send(usfd,buf,1,0);
	
		send_fd(usfd,sfd);
		
		buf[0]=c+48;
		send(usfd,buf,1,0);

		for(int i=0;i<5;i++)
		{
			if(nsfd[i]>0)
			send_fd(usfd,nsfd[i]);	
		}
		
		 
		char buf1[10];
		recv(usfd,buf1,10,0);
		bkp=atoi(buf1);

		char pid[20];
		sprintf(pid,"%d",getpid());
		send(usfd,pid,strlen(pid),0);
		close(usfd);
	}
	else
	{
		usfd=socket(AF_UNIX,SOCK_STREAM,0);
		if(usfd<0)
		printf("socket error\n");

		printf("signal\n");
		kill(bkp,SIGUSR1);

		struct sockaddr_un serv1;
		serv1.sun_family=AF_UNIX;
		strcpy(serv1.sun_path,"mysocket1");
		int b=connect(usfd,(struct sockaddr*)&serv1,sizeof(serv1));
		if(b<0)
		printf("connect error\n");
				
		sfd=recv_fd(usfd);
		printf("sfd %d\n",sfd);
		if(m<sfd)
		m=sfd;
				
		char buf[1];
		recv(usfd,buf,1,0);
		c=buf[0]-48;
		printf("connections : %d\n",c);

		for(int i=0;i<5;i++)
		{
			if(i<c)
			{
				nsfd[i]=recv_fd(usfd);
				printf("nsfd %d\n",nsfd[i]);
				if(m<nsfd[i])
				m=nsfd[i];
				
			}
			else
			nsfd[i]=0;
		}

		printf("this server is available\n");
		up=1;
		close(usfd);
	}
	
}
int main()
{ 
	signal(SIGINT,fn);

	printf("pid is %d\n",getpid());
	printf("enter port\n");
	scanf("%d",&port);

	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(port);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	int stat=bind(sfd,(struct sockaddr*)&address,sizeof(address));
	if(stat<0)
	printf("bind failed\n");

	listen(sfd,2);

	m=sfd;
	for(int i=0;i<5;i++)
	nsfd[i]=0;

	while(1)
	{
		while(up==0);
		struct timeval tvptr;
		fd_set rset;
		tvptr.tv_sec=1;
		tvptr.tv_usec=0;
		FD_ZERO(&rset);
				
		for(int i=0;i<5;i++)
		{
			if(nsfd[i]>0)
			FD_SET(nsfd[i],&rset);
		}
		FD_SET(sfd,&rset);

		int ret=select(m+1,&rset,NULL,NULL,&tvptr);
		if(ret>0)
		{
			 
			if(FD_ISSET(sfd,&rset)&&c<5)
			{ 
				printf("new connection for this server\n");
				for(int i=0;i<5;i++)
				{
					if(nsfd[i]==0)
					{
						nsfd[i]=accept(sfd,NULL,NULL);
						printf("%d\n",nsfd[i]);
						if(m<nsfd[i])
						m=nsfd[i];
						break;
					}
				}
				c++;
				printf("no of con %d\n",c);
			}
			for(int i=0;i<5;i++)
			{
				if(nsfd[i]>0&&FD_ISSET(nsfd[i],&rset))
				{
					char buf[20];
					memset(buf,'\0',20);
					recv(nsfd[i],buf,20,0);
					if(strlen(buf)==1&&buf[0]=='x')
					{
						nsfd[i]=0;
						c--;
						printf("client removed\n");
						printf("no of connections %d\n",c);
					}
					else
					{
						for(int j=0;j<5;j++)
						{
							if(nsfd[j]>0&&j!=i)
							send(nsfd[j],buf,strlen(buf),0);
						}
					}
				}
			}
		}	
	}
	
	
	
}
