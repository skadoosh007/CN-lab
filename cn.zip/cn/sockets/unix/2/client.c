#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
int n;
int sfd[3];
void fn()
{
	int s;
	char buf[20];
	printf("enter server\n");
	scanf("%d",&s);
	printf("enter msg\n");
	scanf("%s",buf);
	send(sfd[s-1],buf,strlen(buf),0);
}
int main()
{
	int m=-1,n;
	printf("no of servers max-->3?\n");
	scanf("%d",&n);
	
	
	signal(SIGINT,fn);
	
	for(int i=0;i<3;i++)
	sfd[i]=0;
	printf("enter server nums (1 2 3)\n");
	
	for(int i=0;i<n;i++)
	{
		int k;
		scanf("%d",&k);
		k--;

		sfd[k]=socket(AF_INET,SOCK_STREAM,0);
		if(sfd[k]==-1)
		printf("socket error\n");

		if(m<sfd[k])
		m=sfd[k];
		
		struct sockaddr_in server;		
		server.sin_port=htons(9000+k);
		server.sin_family=AF_INET;
		server.sin_addr.s_addr=inet_addr("127.0.0.1");
		
		int c=connect(sfd[k],(struct sockaddr *)&server,sizeof(server));
		if(c<0)
		printf("connect error\n ");
	}

	while(1)
	{
		struct timeval tvptr;
		tvptr.tv_usec=0;
		tvptr.tv_sec=1;
		fd_set readset;
		FD_ZERO(&readset);
		for(int i=0;i<3;i++)
		{
			if(sfd[i]>0)
			FD_SET(sfd[i], &readset);
		}
	
		int s=select(m+1,&readset,NULL,NULL,&tvptr);
		if(s>0)
		{
			for(int i=0;i<3;i++)
			{
				if(sfd[i]>0&&FD_ISSET(sfd[i],&readset))
				{
					char buff[20];
					memset(buff,'\0',20);
					recv(sfd[i],buff,sizeof(buff),0);
					printf("msg from server %d : %s\n",i+1,buff);
					
				}
			}
		}
	}
}
