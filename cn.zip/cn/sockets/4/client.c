#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

int main()
{
	int sfd;

	//opening socket
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//connect the socket to address
	connect(sfd,(struct sockaddr*)&address,sizeof(address));
	 
	printf("enter service.. 1 or 2\n");
	int s;
	scanf("%d",&s);
	
	//send req to main server
	char buffer[10];
	buffer[0]=48+s;
	send(sfd,buffer,1,0);
	
	//get the ip address of service required
	recv(sfd,buffer,sizeof(buffer),0);
	printf("port of required service is : %s\n",buffer);
	int port=atoi(buffer);

	//connect to server
	int sfd1=socket(AF_INET,SOCK_STREAM,0);
	if(sfd1==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address1;
	address1.sin_family=AF_INET;
	address1.sin_port=htons(port);
	address1.sin_addr.s_addr=inet_addr("127.0.0.1");

	//connect the socket to address
	connect(sfd1,(struct sockaddr*)&address1,sizeof(address1));
	while(1)
	{
		char buffer[100];
		memset(buffer,'\0',100);
		printf("enter message\n");
		read(0,buffer,sizeof(buffer));
		send(sfd1,buffer,strlen(buffer),0);
		memset(buffer,'\0',100);
		recv(sfd1,buffer,sizeof(buffer),0);
		printf("message from server: %s\n",buffer);
 	}

	//close
	close(sfd);

}
