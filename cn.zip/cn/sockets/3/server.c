#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>

int main()
{
	int sfd;

	//opening socket
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd==0)
	{
		printf("socket error\n");
		return 0;
	}

	struct sockaddr_in address;
	address.sin_family=AF_INET;
	address.sin_port=htons(9001);
	address.sin_addr.s_addr=inet_addr("127.0.0.1");

	//bind the socket to address
	bind(sfd,(struct sockaddr*)&address,sizeof(address));
	
	listen(sfd,5);

	int nsfd;
	int c=0;
	while(1)
	{
		nsfd=accept(sfd,NULL,NULL);
		printf("new client request for service:");
		char buffer[100];
		recv(nsfd,buffer,1,0);
		int s=buffer[0]-48;
		printf("%d\n",s);		

		int sfd1=socket(AF_INET,SOCK_STREAM,0);
		
		struct sockaddr_in address;
		address.sin_family=AF_INET;
		address.sin_addr.s_addr=inet_addr("127.0.0.1");

		if(s==1)
		address.sin_port=htons(9002);
		else
		address.sin_port=htons(9003);
		
		connect(sfd1,(struct sockaddr*)&address,sizeof(address));
		
		dup2(nsfd,sfd1);

		//close(nsfd);
		//close(sfd1);		 		
	}	
	//close
	close(sfd)
}

