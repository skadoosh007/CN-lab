#include<sys/msg.h>
#include<sys/ipc.h>
#include<stdio.h>
#include<unistd.h>
struct buffer{
long type;
char msg[10];
} buf;
int main()
{
	key_t key=ftok("myfile",80);
	int msgid=msgget(key,0666|IPC_CREAT);
	msgrcv(msgid,&buf,sizeof(buf),1,0);
	printf("%s",buf.msg);
	
}
