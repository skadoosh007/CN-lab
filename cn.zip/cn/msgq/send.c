#include<sys/msg.h>
#include<sys/ipc.h>
#include<stdio.h>
#include<unistd.h>
struct buffer
{
long type;
char msg[10];
} buf;
int main()
{
	key_t key=ftok("myfile",80);
	int msgid=msgget(key,0666|IPC_CREAT);
	scanf("%s",buf.msg);
	buf.type=1;
	msgsnd(msgid,&buf,sizeof(buf),0);
	
}

