#include <stdio.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/time.h>
       #include <sys/types.h>
       #include <unistd.h>
#include <sys/select.h>
#include <string.h>
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include<signal.h>
#include <fcntl.h>
#include <sys/stat.h>


int main()
{

	char buff[100];
	char *screen = "screen";

	int ff = open(screen,O_RDONLY);
	while(1)
	{
		int g = read(ff,buff,sizeof(buff));
		if(g>0)
		{
		buff[g]='\0';
		printf("breaking news : %s \n",buff);}

	}
}