#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/time.h>
       #include <sys/types.h>
       #include <unistd.h>
#include <sys/select.h>
#include <string.h>
#include <sys/ipc.h>
#include<signal.h>
#include <sys/stat.h>
int special=0;

void signals(int  x)
{
	special=0;
}

int main()
{
	signal(SIGUSR1,signals);
	char *screen = "screen";
	mkfifo(screen,0666);

	char *report[3] = {"./r1","./r2","./r3"};

	int fd[3];

	for(int i=0;i<3;i++)
		fd[i]=fileno(popen(report[i],"r"));

	int wfd = fileno(popen("./doc","w"));

	fd_set readfd;

	for(int i=0;i<3;i++)
		FD_SET(fd[i],&readfd);

	char *reader[2] = {"./reader1" , "./reader2"};

	int rfd[2];
	rfd[0]=fileno(popen(reader[0],"w"));
	rfd[1]=fileno(popen(reader[1],"w"));

	int pid = getpid();

	char pi[20];
	sprintf(pi , "%d",pid);

	write(rfd[0],pi ,strlen(pi)+1);
	write(rfd[1],pi ,strlen(pi)+1);
	 
	printf("rdds are %d   %d \n",rfd[0],rfd[1] );

	int alter = 0;

	while(1)
	{
		for(int i=0;i<3;i++)
		FD_SET(fd[i],&readfd);
	 

		select(15 , &readfd , NULL , NULL , NULL);

		char buff[100];
		for(int i=0;i<3;i++)
		if(FD_ISSET(fd[i],&readfd))
		{


			int x = read(fd[i],buff,sizeof(buff));

			if(x>0)
			{
			//buff[x]='\0';

			printf("buff is :- %s \n",buff );

			if(buff[0]=='/' && buff[1]=='d')
			{
				write(wfd,buff,strlen(buff)+1);
			}

				

				if(buff[0]>=48 && buff[0]<=57)
					{write(rfd[alter] , buff ,strlen(buff)+1);special=1;}

				if(!special)
				{
				
				int pp = write(rfd[alter] , buff ,strlen(buff)+1);

				printf("special  is #### %d\n", special);
				
				 
				alter = (alter+1)%2;
				}
			}			

		}
		 
		FD_ZERO(&readfd);
	 

	}

	return 0;
}
