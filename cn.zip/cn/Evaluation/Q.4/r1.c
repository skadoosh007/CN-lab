#include <stdio.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/time.h>
       #include <sys/types.h>
       #include <unistd.h>
#include <sys/select.h>
#include <string.h>


int main()
{

	 
	
	while(1)
	{
		printf("enter news for reporter1 \n");
		char buff[100];
		fgets(buff,100,stdin);

		int nn = strlen(buff);
		buff[nn]='\0';

	write(1,buff,strlen(buff)+1);
	sleep(3);
	}
	return 0;
}