#include <iostream>
 
#include <unistd.h>
#include <netinet/in.h>
#include <sys/time.h>
       #include <sys/types.h>
       #include <unistd.h>
#include <sys/select.h>
#include <bits/stdc++.h>
#include <string.h>

using namespace std;

int main()
{

	char buff[100];

	ofstream fin;

	fin.open("store.txt",ios::app);

 

	 

	while(1)
	{
	int g = read(0,buff,sizeof(buff));

	if(g>0)
	{
		 
		buff[g]='\0';int j=0;

		 for(int i=2;i<strlen(buff);i++)
		 	buff[j++] = buff[i];

		 buff[j]='\0';
		fin<<buff<<endl;
	}

	}
	fin.close();
	return 0;
}