 
#include <stdio.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/time.h>
       #include <sys/types.h>
       #include <unistd.h>
#include <sys/select.h>
#include <string.h>
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <sys/stat.h>
#include<signal.h>
#include <fcntl.h>
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <sys/ipc.h>
#include <arpa/inet.h>

#define MAX 80 
#define  SA struct sockaddr 

int flag =0 ;
int sigpid;

int ffd ; 

void func(int sockfd) 
{ 
    char buff[MAX]; 
    int n; 
    for (;;) { 
        bzero(buff, sizeof(buff)); 
        
        n = 0; 
          	char bu[2]=" ";
        write(sockfd,bu , sizeof(bu));
        read(sockfd, buff, sizeof(buff));
        write(ffd, buff, strlen(buff)+1); 
           printf("From Server : %s", buff); 
       
        if ((strncmp(buff, "exit", 4)) == 0) { 
            printf("Client Exit...\n"); flag=0;

            kill(sigpid,SIGUSR1);
            break; 
        } 
    } 
} 


int main()
{

	char buff[100];
	printf("i m reader1\n");

	char *screen = "screen";
	 
	 ffd = open(screen , O_WRONLY);

 
	struct sockaddr_in addr;

	addr.sin_family =AF_INET;
	addr.sin_addr.s_addr = inet_addr("127.0.0.1");


	int sfd = socket(AF_INET , SOCK_STREAM , 0);

	int g = read(0,buff,sizeof(buff));
	if(g>0)
		sigpid = atoi(buff);


	while(1)
	{
	int g = read(0,buff,sizeof(buff));
	 
	if(g>0)
	{
		buff[g]='\0';
		printf("news for reader1 ::  %s \n",buff );

		if(buff[0]>=48 && buff[0]<=57 && flag==0)
		{
			char *port = strtok(buff , "$");
			int ports = atoi(port);

			 
			addr.sin_port = htons(ports);

			 if (connect(sfd, (SA*)&addr, sizeof(addr)) != 0) { 
        printf("connection with the server failed...\n"); 
        exit(0); 
    } 

    flag=1;
     func(sfd); 


     close(sfd);
		}
		else
			write(ffd,buff , strlen(buff)+1);
	}

	}

	return 0;
}