#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/wait.h>
#include<sys/poll.h>
#include<sys/stat.h>
#include<semaphore.h>
#include<fcntl.h>
#include<sys/msg.h>
#include <netinet/in.h>
#include <netinet/in.h>
#include <string.h>
#include<sys/socket.h>
#include<arpa/inet.h>

int main()
{
  key_t key1=10;
  int *p1;
  int shmid1=shmget(key1,10,0666|IPC_CREAT);
  p1=(int*)shmat(shmid1,(void*)0,0);

  char buffer[1024]={0};
  printf("you're connected to s1. \n");

  read( 3 , buffer, 1024);
  printf("%s\n",buffer);
  read( 0 , buffer, 1024);
  send(2 , buffer , strlen(buffer) , 0 );
  p1[0]=0;
  kill(getppid(),SIGUSR1);
}
