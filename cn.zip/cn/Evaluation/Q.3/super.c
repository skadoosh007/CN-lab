#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/wait.h>
#include<sys/poll.h>
#include<sys/stat.h>
#include<semaphore.h>
#include<fcntl.h>
#include<sys/msg.h>
#include <netinet/in.h>
#include <string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<pthread.h>

int nl=0;
int sfd[10];
char *port[10];
char *exec[10];
char *protc[10];
int limit[10];
char *offer[10];
char *loc[10];        //loc for location internal or external;
int cnt[10];    //count

key_t key1=10;
int shmid1,*p1;

void *serv(void *s)
{
  int sfd=*((int *)s);
  printf("\n inside service \n");
  char buffer[1024] = {0};
  read(sfd,buffer,1024);
  int l=strlen(buffer);
  sprintf(buffer,"The string length is %d",l-1);
  send(sfd,buffer,strlen(buffer),0);
  p1[0]=1;
  kill(getpid(),SIGUSR1);
}

void fn1()
{
  cnt[p1[0]]--;
  printf("\n count of service s%d decreased \n",p1[0]+1);
}
int main()
{
  shmid1=shmget(key1,10,0666|IPC_CREAT);
  p1=(int*)shmat(shmid1,(void*)0,0);
  signal(SIGUSR1,fn1);
  char buffer[1024] = {0};
  struct sockaddr_in addr,caddr;
  int addrlen;

  nl=4;
  port[0]="9011"; exec[0]="./s1"; protc[0]="tcp"; loc[0]="external"; limit[0]=25; offer[0]="process";
  port[1]="9022"; exec[1]="./s2"; protc[1]="tcp"; loc[1]="internal"; limit[1]=15; offer[1]="thread";
  port[2]="9033"; exec[2]="./s3"; protc[2]="udp"; loc[2]="internal"; limit[2]=2500; offer[2]="function";
  port[3]="9044"; exec[3]="./s4"; protc[3]="tcp"; loc[3]="external"; limit[3]=2500; offer[3]="process";


  for(int i=0;i<nl;i++)
  {

  addr.sin_family=AF_INET;
  addr.sin_port=htons(atoi(port[i]));
  addrlen=sizeof(addr);

  if(inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr)<=0)
  {
        printf("\nInvalid address/ Address not supported \n");
        return 0;
  }
  printf("%d , %d , %d \n",ntohs(addr.sin_port),addr.sin_family,addr.sin_addr.s_addr);

  if((sfd[i]=socket(AF_INET,SOCK_STREAM,0))==0)
  {
    printf("\n socket error \n");
    return 0;
  }

  if(bind(sfd[i],(struct sockaddr *)&addr,(socklen_t)addrlen)<0)
  {
    printf("\n bind error \n");
    return 0;
  }

  if(listen(sfd[i],10)<0)
  {
    printf("\n listen error \n");
    return 0;
  }

  }

  int nsfd;
  fd_set rfd;
  while(1)
  {
    struct timeval tv;
    tv.tv_sec=5;
    tv.tv_usec=0;

    FD_ZERO(&rfd);
    int maxfd=0;
    for(int i=0;i<nl;i++)
    {
      FD_SET(sfd[i],&rfd);
      if(sfd[i]>maxfd)
      maxfd=sfd[i];
    }

    int s=select(maxfd+1,&rfd,NULL,NULL,&tv);

    if(s>0)
    {
      for(int i=0;i<nl;i++)
      {
      if(FD_ISSET(sfd[i],&rfd))
      {
        if(cnt[i]<=limit[i])
        {
        cnt[i]++;
        printf("\npresent count of s%d is %d\n",i+1,cnt[i] );

        if(protc[i]=="tcp")
        {
          if((nsfd=accept(sfd[i],(struct sockaddr *)&addr,(socklen_t *)&addrlen))<0)
          {
            printf("\n accept error \n)");
            return 0;
          }
          printf("\n accepted %d\n",i);
        }

        if(loc[i]=="external"&&offer[i]=="process")
        {
          int c=fork();
          if(c>0)
          {
            close(nsfd);
          }
          else
          {
            printf("\n connected to sfd[%d] \n",i);

            close(sfd[i]);
            dup2(nsfd,2);
            dup2(nsfd,3);
            char* ch[]={exec[i],NULL};
            execvp(ch[0],ch);
          }
        }

        if(loc[i]=="internal" && offer[i]=="thread")
        {
          printf("\nbefore thread create\n");
          pthread_t pt;
          int *nsfd1;
          nsfd1=&nsfd;
          int iret=pthread_create(&pt,NULL,serv,(void *)nsfd1);
        }
      }
      }
      }
    }
  }
}
